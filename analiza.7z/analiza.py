import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

heapOptymistic = pd.read_csv('HeapTestTimeRandom', delimiter = " ", index_col="Size")
quickOptymistic = pd.read_csv('QuickTestTimeRandom', delimiter = " ", index_col="Size")
optimalQuickOptymistic = pd.read_csv('OptimalQuickTestTimeRandom', delimiter = " ", index_col="Size")
refAlgorythmOptymistic = pd.read_csv('refTestTimeRandom', delimiter = " ", index_col="Size")
insortOptymistic = pd.read_csv('InsortTestTimeRandom', delimiter = " ", index_col="Size")
selectionOptymistic = pd.read_csv('SelectionTestTimeRandom', delimiter = " ", index_col="Size")
frames = [heapOptymistic,quickOptymistic,optimalQuickOptymistic,refAlgorythmOptymistic,insortOptymistic,selectionOptymistic]
result = pd.concat(frames)
plt.close('all')
plt.title("Przypadek losowy")
plt.xlabel("Rozmiar zestawy danych")
plt.ylabel("Czas")
plt.grid()
plt.plot(result, marker = ".", linestyle = "none")
plt.legend(["HeapSort","QuickSort","Optymalny QuickSort","Algorytm Referencyjny", "InSort","SelectionSort"])
plt.savefig("DaneLosowe.png", dpi=300)
plt.show()
